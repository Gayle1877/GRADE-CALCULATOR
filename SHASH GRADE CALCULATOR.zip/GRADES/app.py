from flask import Flask, render_template, request, flash

app = Flask(__name__)
app.secret_key = 'some_secret'  # Required for flash messages

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            prelim_grade = float(request.form['prelim_grade'])
            if not (0 <= prelim_grade <= 100):
                flash("Prelim grade must be between 0 and 100.")
            else:
                result = calculate_grades(prelim_grade)
                flash(result)
        except ValueError:
            flash("Please enter a valid number for Prelim grade.")

    return render_template('index.html')

def calculate_grades(prelim):
    passing_grade = 75
    max_midterm_final = 0.30 * 100 + 0.50 * 100

    if prelim >= passing_grade:
        return "You have already passed the subject."

    required_overall_score = passing_grade - 0.20 * prelim

    if required_overall_score > max_midterm_final:
        return "It is impossible to pass the subject with this Prelim grade."

    min_midterm_final = required_overall_score / 0.80
    return f"Minimum Midterm and Final grades needed: {min_midterm_final:.2f}"

if __name__ == '__main__':
    app.run(debug=True)

