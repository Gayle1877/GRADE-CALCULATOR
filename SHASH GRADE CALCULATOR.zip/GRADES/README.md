# Grade Calculator

## Description

This is a Flask web application that calculates the required Midterm and Final grades needed to pass a subject based on the Prelim grade. The application calculates if it is possible to pass and provides the required grades if achievable.

## Installation

1. Clone this repository.
2. Install Flask:
   ```bash
   pip install Flask
